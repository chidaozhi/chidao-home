import $ from 'jquery'
window.$ = $;
window.jQuery = $;
export default $